#following array maps keys used by Field Surveyors to 
#names used by Civil-3D Description Keys and Figure Library
#this list is not required; codes not in the list pass through unchanged
%pointCodes = (
	"1" => "CLPV",
	"2" => "FLPV",
	"3" => "TOE",
	"4" => "NG",
	"5" => "TOP",
	"6" => "GB",
	"7" => "CATCH",
	"8" => "OFFSET",
	"9" => "GS",
	"10" => "CLDITCH",
	"11" => "DAYLIGHT",
	"12" => "CLFEATURE",
	"13" => "CLSWALE",
	"14" => "CLDIRTRD",
	"17" => "CROWN",
	"18" => "LIPC",
	"19" => "LIPA",
	"20" => "ASPH",
	"21" => "EOA",
	"22" => "TBCA",
	"23" => "CONC",
	"24" => "EOC",
	"25" => "TBCC",
	"26" => "WALK",
	"27" => "HCRAMP",
	"28" => "CURBCUT",
	"29" => "PAN",
	"30" => "BRICK",
	"31" => "EOBRICK",
	"32" => "GRAVEL",
	"33" => "EOG",
	"34" => "MARBLE",
	"35" => "EOMARBLE",
	"36" => "SAWCUT",
	"37" => "PV.CA",
	"50" => "BUSH",
	"51" => "CLIFFBASE",
	"52" => "CLIFFEDGE",
	"53" => "DIRTRD",
	"54" => "HEDGE",
	"55" => "LSCAPE",
	"56" => "EDGELSCAPE",
	"57" => "MARSH",
	"58" => "EDGEMARSH",
	"59" => "POTHOLE",
	"60" => "RIPRAP",
	"61" => "EDGERIPRAP",
	"62" => "RCKOUTCROP",
	"63" => "RCKOVERHANG",
	"64" => "SPRINGHEAD",
	"65" => "SPRINKLER",
	"66" => "TRAIL",
	"67" => "CONIFER",
	"68" => "DECIDUOUS",
	"69" => "DEADTREE",
	"70" => "TREELINE",
	"71" => "WATEREDGE",
	"72" => "STOCKPILE",
	"73" => "STOCKPILEEDGE",
	"74" => "MUCKLINE",
	"75" => "ROCK",
	"76" => "PLAYGROUND",
	"77" => "SAND",
	"78" => "EDGESAND",
	"90" => "ABUT",
	"91" => "BLEACHERS",
	"92" => "BOLLARD",
	"93" => "BRIDGE",
	"94" => "CAISSON",
	"95" => "CATTLEGRD",
	"96" => "EDGING",
	"97" => "EXPJOINT",
	"98" => "FX",
	"99" => "FXEND",
	"100" => "FXPOST",
	"101" => "FLAGPOLE",
	"102" => "FUELCELL",
	"103" => "PADFUEL",
	"104" => "GATE",
	"105" => "HANDRAIL",
	"106" => "MAILBOX",
	"107" => "MAILDROP",
	"108" => "BENCHPARK",
	"109" => "BENCHPICNIC",
	"110" => "GRILL",
	"111" => "PICNICTABLE",
	"112" => "POOL",
	"113" => "PUMPOIL",
	"114" => "RETWALL",
	"115" => "SIGNSP",
	"116" => "SIGNCL",
	"117" => "SIGNEC",
	"118" => "STAIRS",
	"119" => "STATPED",
	"120" => "STATUE",
	"121" => "ST.TK",
	"122" => "TOWER",
	"123" => "TRASHCAN",
	"124" => "TRASHENC",
	"125" => "WALL",
	"126" => "WINDMILL",
	"127" => "WOODFORM",
	"128" => "TPOST",
	"129" => "SILTFX",
	"130" => "SILO",
	"131" => "GATESTOP",
	"132" => "ASHTRAY",
	"133" => "FIREPIT",
	"134" => "PLANTER",
	"140" => "HVAC",
	"141" => "BLDGCOLUMN",
	"142" => "BLDGCOR",
	"143" => "BLDGLINEPROJ",
	"144" => "BLDGLINE",
	"145" => "BUSSHELTER",
	"146" => "CANOPY",
	"147" => "DECK",
	"148" => "DRAINPIPE",
	"149" => "BLDGENTRY",
	"150" => "GAZEBO",
	"151" => "OVERHANG",
	"152" => "WINDWELL",
	"153" => "WINDOW",
	"154" => "FINFLOOR",
	"155" => "TRAILER",
	"156" => "BLDGCOROFFSET",
	"157" => "BLDGOUTHOUSE",
	"170" => "RRCROSSBAR",
	"171" => "RRCROSSPAD",
	"172" => "RRLOCATE",
	"173" => "RRRAIL",
	"174" => "RRSIGPOLE",
	"175" => "RRSWITCH",
	"176" => "RRTIE",
	"180" => "BOREHOLE",
	"181" => "GNDWATERMON",
	"182" => "TESTHOLE",
	"190" => "GREEN",
	"191" => "FRINGE",
	"192" => "ROUGH",
	"193" => "BUNKER",
	"194" => "WATHAZ",
	"195" => "DIRPLAY",
	"200" => "BOXGAS",
	"201" => "GASLOCATE",
	"202" => "GASLOCTEE",
	"203" => "GASMETER",
	"204" => "GASPED",
	"205" => "GASTANK",
	"206" => "GASTOP",
	"207" => "GASVALVE",
	"208" => "VAULTGAS",
	"209" => "GASSTUB",
	"220" => "CLEANOUT",
	"221" => "INVERTSS",
	"222" => "SSLOCATE",
	"223" => "SANMH",
	"224" => "SANTOP",
	"225" => "VAULTSANITARY",
	"226" => "SANPUMP",
	"227" => "SANSTUB",
	"230" => "CHASE",
	"231" => "STRUCDRAIN",
	"232" => "STRUCDROP",
	"233" => "FES",
	"234" => "FLSD",
	"235" => "HEADWALL",
	"236" => "INLETCOR",
	"237" => "INLETEDGE",
	"238" => "INLETFL",
	"239" => "INLETGRATE",
	"240" => "INVERTSD",
	"241" => "LEECH",
	"242" => "SDLOCATE",
	"243" => "STORMMH",
	"244" => "STORMGMH",
	"245" => "SDTOP",
	"246" => "VAULTSTORM",
	"247" => "UNDERDRAIN",
	"248" => "WEIR",
	"249" => "WINGWALL",
	"260" => "CISTERN",
	"261" => "FHYD",
	"262" => "FLUME",
	"263" => "FOUNTAIN",
	"264" => "INVERTWAT",
	"265" => "BOXIRRIG",
	"266" => "IRRIGVALVE",
	"267" => "VAULTIRRIG",
	"268" => "WATLOCATE",
	"269" => "WATLOCTEE",
	"270" => "WATMH",
	"271" => "WATMETER",
	"272" => "WATPUMP",
	"273" => "WATPED",
	"274" => "SPIGOT",
	"275" => "WATTANK",
	"276" => "WATTOP",
	"277" => "WATVALVE",
	"278" => "VAULTWAT",
	"279" => "VENTPIPE",
	"280" => "WELL",
	"281" => "VALVECOUPLER",
	"282" => "WATSTUB",
	"290" => "BOXCATV",
	"291" => "CATVLOCATE",
	"292" => "CATVPED",
	"293" => "BOXELEC",
	"294" => "CONDUIT",
	"295" => "ELECLOCATE",
	"296" => "ELECMH",
	"297" => "ELECMETER",
	"298" => "ELECPED",
	"299" => "ELECSWITCH",
	"300" => "VAULTELEC",
	"301" => "FOLOCATE",
	"302" => "GUYPOLE",
	"303" => "GUYWIRE",
	"304" => "LTDECOR",
	"305" => "LTFLOOD",
	"306" => "LTCAN",
	"307" => "LTPOLE",
	"308" => "ELECOH",
	"309" => "SATDISH",
	"310" => "PHLOCATE",
	"311" => "PHONEMH",
	"312" => "PHONEPED",
	"313" => "VAULTPHONE",
	"314" => "UTPOLE",
	"315" => "TOWERHTPOWER",
	"316" => "TOWERXMIT",
	"317" => "BOXFO",
	"318" => "FOPED",
	"319" => "VAULTFO",
	"320" => "FOMH",
	"330" => "BOXTRAFFIC",
	"331" => "BARRIERCONC",
	"332" => "BARRIERTEMP",
	"333" => "DELINEATOR",
	"334" => "GUARDRAIL",
	"335" => "HANDICAPSYM",
	"336" => "TRAFFICLOCATE",
	"337" => "TRAFFICMETER",
	"338" => "TRAFFICOVERHEAD",
	"339" => "PAINTSTRIPE",
	"340" => "PAINTARROW",
	"341" => "SIGPOLE",
	"342" => "SPIKESTRIP",
	"343" => "STOPBARHSNG",
	"344" => "TRAFFICSWITCH",
	"345" => "VEHICHT",
	"346" => "WHEELSTOP",
	"360" => "BOXUNK",
	"361" => "UNKCO",
	"362" => "UNKLOCATE",
	"363" => "UNKMH",
	"364" => "UNKOH",
	"365" => "UNKPED",
	"366" => "UNKPUMP",
	"367" => "UNKSTRUC",
	"368" => "UNKSWITCH",
	"369" => "UNKVALVE",
	"370" => "VAULTUNK",
	"371" => "UNKFL",
	"372" => "UNKTANK",
	"373" => "UNKSTUB",
	"399" => "CARSONITE",
	"400" => "CHKSHOT",
	"401" => "FNDCTRL",
	"402" => "CT.FT",
	"403" => "FNDBM",
	"404" => "TBM",
	"405" => "CP",
	"CP" => "CP",
	"406" => "BENCHMK",
	"407" => "FCOGO",
	"408" => "PANELPT",
	"409" => "GPSCALIB",
	"410" => "GPSATOM",
	"411" => "GPSINIT",
	"420" => "SETMON420",
	"421" => "SETMON421",
	"422" => "SETMON422",
	"423" => "SETMON423",
	"424" => "SETMON424",
	"425" => "SETMON425",
	"426" => "SETMON426",
	"427" => "SETMON427",
	"430" => "FNDMON430",
	"431" => "FNDMON431",
	"432" => "FNDMON432",
	"433" => "FNDMON433",
	"434" => "FNDMON434",
	"435" => "FNDMON435",
	"436" => "FNDMON436",
	"437" => "FNDMON437",
	"438" => "FNDMON438",
	"439" => "FNDMON439",
	"440" => "FNDMON440",
	"441" => "FNDMON441",
	"442" => "FNDMON442",
	"443" => "FNDMON443",
	"444" => "FNDMON444",
	"445" => "FNDMON445",
	"500" => "500",
	"501" => "501",
	"502" => "502",
	"503" => "503",
	"504" => "504",
	"505" => "505",
	"506" => "506",
	"507" => "507",
	"508" => "508",
);
#%commandsInNotes = (
#	"A" => "C3",
#	"X" => "C3\nRECALL",
#	"B" => "BEG",
#	"C" => "CLOSE",
#	"CB" => "CLOSE BLD",
#	"CR" => "CLOSE RECT",
#	"E" => "END",
#	"P" => "PC",
#	"R" => "RECALL",
#	"S" => "START",
#	"T" => "CONT"
#);
%commandsAfterShot = (
	"C" => "CLOSE",
	"CLOSE" => "CLOSE",
	"CB" => "CLOSE BLD",
	"E" => "END",
	"END" => "END"
);
%multicurveEnd = (
	"ME" => "MCE",
	"MCE" => "MCE"
);
%commandsWithArgAfterShot = (
	"CR" => "CLOSE RECT"
);
%commandsWithNoArg = (
	"A" => "C3",
	"C3" => "C3",
	"P" => "PC",
	"PC" => "PC",
	"MS" => "MCS",
	"MCS" => "MCS",
);
%commandsWithFigName = (
	"B" => "BEG",
	"BEG" => "BEG",
	"T" => "CONT",
	"CONT" => "CONT",
	"S" => "START",
	"START" => "START",
);
%commandsWithFigNameArcs = (
	"BA" => "BEG",
	"TA" => "CONT"
);
%commandsWithArg = (
	"R" => "RECALL",
	"RECALL" => "RECALL",
);
%controlPoint = ( #these get NEZ lines instead of NE SS lines in the FBK
	"CP" => "CP",
	"405" => "CP"
);

#####################
# Some Global Vars
$figname="";
$curPtNum="";
$lastPtNum="";
$lastFigname="";
%activeStrings=();
$curIsString=0;
$lastWasString=0;
#####################

#In addition to returning the code, this routine also sets the
#$figname and $curIsString global vars.  Not good OO practice,
#but it was the easiest thing to do at the time...  I should
#probably fix it at some point.
#Note that this routine returns a parsed code, followed by any
#additional text that the field surveyor keyed in.  $figname is
#the code without the additional text.
sub parseCode {
	my @args = split(/\s+/, $_[0], 2);
	(my $pc, my $stringid) = ($args[0] =~ /(\d+)\.*(\d*)/);
	if (my $code=$pointCodes{$pc}) {
		$figname="$code$stringid"; # note: global var
		$curIsString = length $stringid; #global; false if len($stringid)==0
		if (length($args[1])>0) {
		  return "$figname $args[1]";
		}
		else {
			return $figname;
		}
	}
	else {
		$figname = "";
	  return $_[0];
	}
}

#adds a BEG or CONT statement if this code has a string id, and this
#point has a different code than the last point
sub hookString {
	if ($figname ne $lastFigname) { #not the same as last; add a BEG or CONT
		if ($activeStrings{$figname}) {
			# this string already exists; add to it
			print OUT "CONT $figname\n";
		}
		else {
			# begin a new string
			print OUT "BEG $figname\n";
		}
  }
}

##########
#the next two routines help handle the multiple-strings-to-one-point thing
sub processPoint {
	$code=parseCode(@_);
	if ($curIsString) {
		hookString;
  }
  elsif ($lastWasString) {
  	# last point was in a String, and this point is not, so add an END statement
  	print OUT "END\n";
  	$lastWasString=0;
  }
	print OUT "NE SS $curPtNum $in[1] $in[2] $in[3] \"$code\"\n";
}

sub generateNextPtNum {
	return $_nextAutogenPtNum++;
}
##########

if ($#ARGV<0) {
	die "Syntax:\nperl fbk.pl <input file name> <start ptnum for new pts>\n";
}
$fname=$ARGV[0];
$fname =~ s/\.[^.]*$//;
open(IN,$ARGV[0]);
open(OUT,">${fname}.fbk");
if ($#ARGV>0) {
	$_nextAutogenPtNum=$ARGV[1];
}
else {
	$_nextAutogenPtNum=100000;
}
while (<IN>) {
	$curIsString=0;
	@in = split(/,/, substr(uc, 0, -1), 5); #note: forces text to be uppercase
	@tok = split(/\s+/, $in[4], 2);
# This part was implemented to handle commands in notes.  But since
# notes don't make it into CSV files, this part is extraneous.
# I have commented it out, but left the code here just in case I want it
# in the future.
#	if ($#in<3) { #if can't split line on commas, assume it's a note
#		@tok = split(/\s+/, substr(uc, 0, -1), 2);
#		if ($c=$commandsInNotes{$tok[0]}) {
#			if ($commandsWithFigName{$tok[0]}) {
#		    $code = parseCode($tok[1]);
#			  print OUT "$c $code\n";
#			}
#			else {
#				print OUT "$c $tok[1]\n";
#			}
#		}
#		else {
#		  print OUT $_;
#	  }
#	}
#	elsif ($c=$commandsAfterShot{$tok[0]}) {
	if ($c=$commandsAfterShot{$tok[0]}) {
		$code = parseCode($tok[1]);
		print OUT "NE SS $in[0] $in[1] $in[2] $in[3] \"$code\"\n$c\n";
		$curIsString=0; #this prevents the string stuff from adding an extra END statement
		$activeStrings{$figname}=0; #ensures string stuff will not add a CONT if ptcode is reused
	}
	elsif ($c=$multicurveEnd{$tok[0]}) {
		$code = parseCode($tok[1]);
		print OUT "NE SS $in[0] $in[1] $in[2] $in[3] \"$code\"\n$c\n";
	}
	elsif ($c=$commandsWithNoArg{$tok[0]}) {
		$code = parseCode($tok[1]);
		if ($curIsString) {
			hookString;
	  }
		print OUT "$c\nNE SS $in[0] $in[1] $in[2] $in[3] \"$code\"\n";
	}
	elsif ($c=$commandsWithFigName{$tok[0]}) {
		$code = parseCode($tok[1]);
		print OUT "$c $figname\nNE SS $in[0] $in[1] $in[2] $in[3] \"$code\"\n";
	}
	elsif ($c=$commandsWithArg{$tok[0]}) {
		@tok = split(/\s+/, $tok[1], 2);
		$code = parseCode($tok[1]);
		print OUT "$c $tok[0]\nNE SS $in[0] $in[1] $in[2] $in[3] \"$code\"\n";
  }
	elsif ($c=$commandsWithArgAfterShot{$tok[0]}) {
		@tok = split(/\s+/, $tok[1], 2);
		$code = parseCode($tok[1]);
		print OUT "NE SS $in[0] $in[1] $in[2] $in[3] \"$code\"\n$c $tok[0]\n";
		$curIsString=0; #this prevents the string stuff from adding an extra END statement
		$activeStrings{$figname}=0; #ensures string stuff will not add a CONT if ptcode is reused
  }
	elsif ($c=$controlPoint{$tok[0]}) {
		$code = $c; # need to do this for string parsing
    if ($lastWasString) {
  	  # last point was in a String, and this point is not, so add an END statement
  	  print OUT "END\n";
    	$lastWasString=0;
    }
		print OUT "NEZ $in[0] $in[1] $in[2] $in[3] \"$c $tok[1]\"\n";
	}
	elsif ($c=$commandsWithFigNameArcs{$tok[0]}) {
		$code = parseCode($tok[1]);
		print OUT "$c $figname\nC3\nNE SS $in[0] $in[1] $in[2] $in[3] \"$code\"\n";
	}
	elsif ($tok[0] eq "X") {
		$code = parseCode($tok[1]);
		print OUT "C3\nRECALL $lastPtNum\nNE SS $in[0] $in[1] $in[2] $in[3] \"$code\"\n";
	}
	elsif ($tok[0] eq "RE") {
		@tok = split(/\s+/, $tok[1], 2);
		$code = parseCode($tok[1]);
		print OUT "NE SS $in[0] $in[1] $in[2] $in[3] \"$code\"\nRECALL $tok[0]\nEND\n";
	}
	elsif ($tok[0] eq "RC") {
		@tok = split(/\s+/, $tok[1], 2);
		$code = parseCode($tok[1]);
		print OUT "NE SS $in[0] $in[1] $in[2] $in[3] \"$code\"\nRECALL $tok[0]\nCLOSE\n";
	}
	elsif ($tok[0] eq "BR") {
		@tok = split(/\s+/, $tok[1], 2);
		$code = parseCode($tok[1]);
		print OUT "BEG $figname\nRECALL $tok[0]\nNE SS $in[0] $in[1] $in[2] $in[3] \"$code\"\n";
	}
	elsif ($tok[0] eq "BM") {
		$code = parseCode($tok[1]);
		print OUT "BEG $figname\nMCS\nNE SS $in[0] $in[1] $in[2] $in[3] \"$code\"\n";
	}
	elsif ($tok[0] eq "MC") {
		$code = parseCode($tok[1]);
		print OUT "MCE\nNE SS $in[0] $in[1] $in[2] $in[3] \"$code\"\nCLOSE\n";
	}
	else {
		$ptdesc=$in[4];
		while ($ptdesc =~ /(\d+\.\d+)\.(\d+\.\d+.*)/) {
			$ptdesc=$2;
			$curPtNum=generateNextPtNum;
			processPoint($1);
			if ($curIsString) {
				$activeStrings{$figname}=1; #make sure the list contains an entry for this string
			}
			$lastWasString=$curIsString;
			$lastFigname=$figname;
			$figname="";
		}
		$curPtNum=$in[0];
		processPoint($ptdesc);
	}
	#prepare for next loop
	if ($curIsString) {
		$activeStrings{$figname}=1; #make sure the list contains an entry for this string
	}
	$lastWasString=$curIsString;
	$lastFigname=$figname;
	$lastPtNum=$in[0];
	$figname="";
}
close(IN);
close(OUT);